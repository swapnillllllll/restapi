<?php

class lat_model extends CI_Model{

  public function __construct(){
    parent::__construct();
    $this->load->database();
  }

  public function get_lat(){

    $this->db->select("*");
    $this->db->from("tbl_lat");
    $query = $this->db->get();

    return $query->result();
  }

   public function insert_lat($data = array()){

       return $this->db->insert("tbl_lat", $data);
   }

   public function delete_lat($id){

     // delete method
     $this->db->where("id", $id);
     return $this->db->delete("tbl_lat");
   }

   public function get_lat_long($lat,$long){
    $array = array('lat' => $lat, 'long' => $long);    // get data
    $this->db->where($array);
    $query = $this->db->get();

    return $query->result();
  }

   public function update_lat_information($id, $informations){

      $this->db->where("id", $id);
      return $this->db->update("tbl_lat", $informations);
   }
}

 ?>
