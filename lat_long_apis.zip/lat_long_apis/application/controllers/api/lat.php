<?php

require APPPATH.'libraries/REST_Controller.php';

class Student extends REST_Controller{

  public function __construct(){

    parent::__construct();
    //load database
    $this->load->database();
    $this->load->model(array("api/lat_model"));
    $this->load->library(array("form_validation"));
    $this->load->helper("security");
  }

  /*
    INSERT: POST REQUEST TYPE
    UPDATE: PUT REQUEST TYPE
    DELETE: DELETE REQUEST TYPE
    LIST: Get REQUEST TYPE
  */

  // POST: <project_url>/index.php/student
  public function index_post(){
    // insert data method

    //print_r($this->input->post());die;

    // collecting form data inputs
    $latitude = $this->security->xss_clean($this->input->post("latitude"));
    $longitude = $this->security->xss_clean($this->input->post("longitude"));

    // form validation for inputs
    $this->form_validation->set_rules("latitude", "Latitude", "required");
    $this->form_validation->set_rules("longitude", "Longitude", "required");


    // checking form submittion have any error or not
    if($this->form_validation->run() === FALSE){

      // we have some errors
      $this->response(array(
        "status" => 0,
        "message" => "All fields are needed"
      ) , REST_Controller::HTTP_NOT_FOUND);
    }else{

      if(!empty($latitude) && !empty($longitude)){
        // all values are available
      $lat_long=  $this->lat_model->get_lat_long($latitude, $longitude);
        if($lat_long){
        $lat_info = array(
          "latitude" => $latitude,
          "longitude" => $longitude
        );

        if($this->lat_model->insert_lat($lat_info)){

          $this->response(array(
            "status" => 1,
            "message" => "Data has been created"
          ), REST_Controller::HTTP_OK);
        }else{

          $this->response(array(
            "status" => 0,
            "message" => "Failed to create data"
          ), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
        }
      }else{
        // we have some empty field
        $this->response(array(
          "status" => 0,
          "message" => "Data already exist!"
        ), REST_Controller::HTTP_NOT_FOUND);
      }
      }else{
        // we have some empty field
        $this->response(array(
          "status" => 0,
          "message" => "All fields are needed"
        ), REST_Controller::HTTP_NOT_FOUND);
      }
    }

    /*$data = json_decode(file_get_contents("php://input"));

    $name = isset($data->name) ? $data->name : "";
    $email = isset($data->email) ? $data->email : "";
    $mobile = isset($data->mobile) ? $data->mobile : "";
    $course = isset($data->course) ? $data->course : "";*/


  }

  // PUT: <project_url>/index.php/student
  public function index_put(){
    // updating data method
    //echo "This is PUT Method";
    $data = json_decode(file_get_contents("php://input"));

    if(isset($data->id) && isset($data->latitude) && isset($data->longitude)){

      $id = $data->id;
      $lat_info = array(
        "latitude" => $data->latitude,
        "longitude" => $data->longitude
      );

      if($this->lat_model->update_lat_information($id, $lat_info)){

          $this->response(array(
            "status" => 1,
            "message" => "Data updated successfully"
          ), REST_Controller::HTTP_OK);
      }else{

        $this->response(array(
          "status" => 0,
          "messsage" => "Failed to update data"
        ), REST_Controller::HTTP_INTERNAL_SERVER_ERROR);
      }
    }else{

      $this->response(array(
        "status" => 0,
        "message" => "All fields are needed"
      ), REST_Controller::HTTP_NOT_FOUND);
    }
  }

  // DELETE: <project_url>/index.php/student
  public function index_delete(){
    // delete data method
    $data = json_decode(file_get_contents("php://input"));
    $id = $this->security->xss_clean($data->id);

    if($this->lat_model->delete_lat($id)){
      // retruns true
      $this->response(array(
        "status" => 1,
        "message" => "Data has been deleted"
      ), REST_Controller::HTTP_OK);
    }else{
      // return false
      $this->response(array(
        "status" => 0,
        "message" => "Failed to delete data"
      ), REST_Controller::HTTP_NOT_FOUND);
    }
  }

  // GET: <project_url>/index.php/student
  public function index_get(){
    // list data method
    //echo "This is GET Method";
    // SELECT * from tbl_students;
    $lat_info = $this->lat_model->get_lat();

    //print_r($query->result());

    if(count($lat_info) > 0){

      $this->response(array(
        "status" => 1,
        "message" => "Data found",
        "data" => $lat_info
      ), REST_Controller::HTTP_OK);
    }else{

      $this->response(array(
        "status" => 0,
        "message" => "No Data found",
        "data" => $lat_info
      ), REST_Controller::HTTP_NOT_FOUND);
    }



  }


/*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
/*::                                                                         :*/
/*::  This routine calculates the distance between two points (given the     :*/
/*::  latitude/longitude of those points). It is being used to calculate     :*/
/*::  the distance between two locations using GeoDataSource(TM) Products    :*/
/*::                                                                         :*/
/*::  Definitions:                                                           :*/
/*::    South latitudes are negative, east longitudes are positive           :*/
/*::                                                                         :*/
/*::  Passed to function:                                                    :*/
/*::    lat1, lon1 = Latitude and Longitude of point 1 (in decimal degrees)  :*/
/*::    lat2, lon2 = Latitude and Longitude of point 2 (in decimal degrees)  :*/
/*::    unit = the unit you desire for results                               :*/
/*::           where: 'M' is statute miles (default)                         :*/
/*::                  'K' is kilometers                                      :*/
/*::                  'N' is nautical miles                                  :*/
/*::  Worldwide cities and other features databases with latitude longitude  :*/
/*::  are available at https://www.geodatasource.com                         :*/
/*::                                                                         :*/
/*::  For enquiries, please contact sales@geodatasource.com                  :*/
/*::                                                                         :*/
/*::  Official Web site: https://www.geodatasource.com                       :*/
/*::                                                                         :*/
/*::         GeoDataSource.com (C) All Rights Reserved 2022                  :*/
/*::                                                                         :*/
/*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
function distance($lat1, $lon1, $lat2, $lon2, $unit) {
  if (($lat1 == $lat2) && ($lon1 == $lon2)) {
    return 0;
  }
  else {
    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
    $unit = strtoupper($unit);

    if ($unit == "K") {
      $k_miles = ($miles * 1.609344);
      // return ($miles * 1.609344);
      $this->response(array(
        "status" => 1,
        "Miles"=>$k_miles,
        "message" => "Data found",
      ), REST_Controller::HTTP_OK);
    } else if ($unit == "N") {
      // return ($miles * 0.8684);
      $n_miles = ($miles * 1.60934);
      // return ($miles * 1.609344);
      $this->response(array(
        "status" => 1,
        "Kilometers"=>$n_miles,
        "message" => "Data found",
      ), REST_Controller::HTTP_OK);
    } else {
      // return $miles;
      $_miles = ($miles);
      // return ($miles * 1.609344);
      $this->response(array(
        "status" => 1,
        "Kilometers"=>$_miles,
        "message" => "Data found",
      ), REST_Controller::HTTP_OK);
    }
  }
}
}

 ?>
