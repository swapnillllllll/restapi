Database name: miles_database

Table code:

CREATE TABLE `tbl_lat` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `lat` text DEFAULT NULL,
 `long` text DEFAULT NULL,
 `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
 `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1
